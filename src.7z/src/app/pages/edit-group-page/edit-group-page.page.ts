import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-group-page',
  templateUrl: './edit-group-page.page.html',
  styleUrls: ['./edit-group-page.page.scss'],
})
export class EditGroupPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
