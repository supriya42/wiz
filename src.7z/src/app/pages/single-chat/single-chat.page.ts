import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-chat',
  templateUrl: './single-chat.page.html',
  styleUrls: ['./single-chat.page.scss'],
})
export class SingleChatPage implements OnInit {
headtxt:any;
  constructor() { }

  ngOnInit() {
  }

}
